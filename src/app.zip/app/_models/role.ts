export class Role {
    id:number;
    role_name: string;
}