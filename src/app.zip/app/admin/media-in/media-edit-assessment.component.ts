import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MediaInService } from './../../_services/mediaIn.service';
import { ToastrService } from 'ngx-toastr';
import {MediaIn} from './../../_models/mediaIn';
@Component({
    selector: 'app-media-assessment',
    templateUrl: './media-edit-assessment.component.html',
})
export class MediaAssessmentEdit implements OnInit {

    diaTitle: string;
    submitted: boolean;
    loading:boolean;
    mediaDetails:MediaIn[] = [];
    stages:[];
    public mediaEdit: FormGroup;
    constructor(private formBuilder: FormBuilder,
        private mediaInService: MediaInService,
        private toastrService: ToastrService,
        private dialogRef: MatDialogRef<MediaAssessmentEdit>,
        @Inject(MAT_DIALOG_DATA) public data: any) {
        this.diaTitle = "Media Inspection";
          this.mediaInService.mediastatus('assessment').subscribe( data => {
            this.stages = data as any;
          });
          this.mediaDetails = data;
    }
    ngOnInit(): void {
        this.mediaEdit = this.formBuilder.group({
            id: [''],
            case_type: ['',[Validators.required]],
            recovery_possibility: [''],
            required_days: [''],
            recovery_percentage: [''],
            access_percentage: [''],
            tampering_required: [''],
            recoverable_data: [''],
            stage: [''],
            no_recovery_reason:[],
            selected_data:[],
            assessment_due_reason:[],
            assessment_due_other_reason:[],
            media_os:[],
            media_firmware:[],
            encryption_status:[],
            extension_required:[],
            extension_day:[],
            remarks:['',[Validators.required]],
           });
           this.modeltoForm(this.data as any);
    }

    modeltoForm(media)
    {
        this.mediaEdit.setValue({
            id:media.id,
            case_type:media.case_type,
            recovery_possibility:media.recovery_possibility,
            required_days:media.required_days,
            recovery_percentage:media.recovery_percentage,
            access_percentage:media.access_percentage,
            tampering_required:media.tampering_required,
            recoverable_data:media.recoverable_data,
            stage:media.stage,
            no_recovery_reason:media.no_recovery_reason,
            selected_data:media.selected_data,
            assessment_due_reason:media.assessment_due_reason,
            assessment_due_other_reason:media.assessment_due_other_reason,
            media_os:media.media_os,
            extension_day:media.extension_day,
            extension_required:media.extension_required,
            media_firmware:media.media_firmware,
            encryption_status:media.encryption_status,
            remarks:""
        });
        if(media['tampered_status'] == "Tampered Media")
        this.f['tampering_required'].setValue('Already Tampered');
        
    }

    onSubmit() {
        this.submitted = true;
        if (this.mediaEdit.invalid) {
            return false;
        }
         this.loading = true;
         let apiToCall: any;
         apiToCall = this.mediaInService.updateMediaAssessment(this.mediaEdit.value);
        apiToCall.subscribe(
            data => {
                this.hide();
                this.toastrService.success('Details Save successfully!', 'Success!',{timeOut: 3000});
                this.toastrService.success('Email has been Send', 'Success!',{timeOut: 3000});
            },
            error=>{
                console.log(error)
            }
        );
    }

    hide() {
        this.dialogRef.close();
    }

    get f() { return this.mediaEdit.controls; }
}